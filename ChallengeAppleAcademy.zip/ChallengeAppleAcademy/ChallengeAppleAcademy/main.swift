//
//  main.swift
//  ChallengeAppleAcademy
//
//  Created by BRUNO MORANO DO LAGO on 14/11/25.
//

import Foundation

import Foundation
 
enum Classe {
    case guerreiro, mago, ladino
}
 
enum Elemento {
    case none, fogo, terra

}
 
struct Personagem {
    var nome: String
    var classe: Classe
    var nivel: Int
    var vidaAtual: Int
    var vidaMaxima: Int
    var forca: Int
    var defesa: Int
    var xp: Int
    var moedas: Int
    var inventario: [String]
}
 
struct Inimigo {
    var nome: String
    var nivel: Int
    var forca: Int
    var defesa: Int
    var elemento: Elemento

}
 
func criarHeroi(nome: String, classe: Classe) -> Personagem {
    switch classe {
        
    case .guerreiro:
        return Personagem(nome: nome, classe: classe, nivel: 1, vidaAtual: 120, vidaMaxima: 120, forca: 12, defesa: 10, xp: 0, moedas: 50, inventario: [])
    case .mago:
        return Personagem(nome: nome, classe: classe, nivel: 1, vidaAtual: 90, vidaMaxima: 90, forca: 15, defesa: 5, xp: 0, moedas: 50, inventario: [])
    case .ladino:
        return Personagem(nome: nome, classe: classe, nivel: 1, vidaAtual: 100, vidaMaxima: 100, forca: 10, defesa: 8, xp: 0, moedas: 50, inventario: [])
    }
}
 
func ataqueFraco(forca: Int) -> Int {
    return forca
}
 
func ataqueForte(forca: Int) -> Int {
    return forca * 2
}
 
func ataqueEspecial(heroi: Personagem) -> Int {
    switch heroi.classe {
        
    case .guerreiro:
        return heroi.forca * 3
    case .mago:
        return heroi.forca * 4
    case .ladino:
        return heroi.forca * 2 + 10
    }
}
 
func calcularRecompensas(nivel: Int) -> (xp: Int, moedas: Int) {
    return (nivel * 120, nivel * 70)
}
 
func exibirStatus(_ p: Personagem) {
    print("===== STATUS =====")
    print("Nome: \(p.nome)")
    print("Classe: \(p.classe)")
    print("Nivel: \(p.nivel)")
    print("Vida: \(p.vidaAtual)/\(p.vidaMaxima)")
    print("Forca: \(p.forca)")
    print("Defesa: \(p.defesa)")
    print("XP: \(p.xp)")
    print("Moedas: \(p.moedas)")
    print("Inventario: \(p.inventario)")
}
 
func subirNivel(heroi: inout Personagem) {
    let necessario = heroi.nivel * 150
    if heroi.xp >= necessario {
        
        heroi.nivel += 1
        heroi.xp = 0
        heroi.forca += 3
        heroi.defesa += 2
        heroi.vidaMaxima += 25
        heroi.vidaAtual = heroi.vidaMaxima
        
        print("Voce subiu para o nivel \(heroi.nivel)!")
    }
}
 
func usarPocao(heroi: inout Personagem) {
    if heroi.inventario.contains("Pocao") {
        heroi.vidaAtual += 40
        
        if heroi.vidaAtual > heroi.vidaMaxima { heroi.vidaAtual = heroi.vidaMaxima }
        if let i = heroi.inventario.firstIndex(of: "Pocao") {
            heroi.inventario.remove(at: i)
        }
        print("Voce usou uma pocao!")
    }
    else {
        print("Voce nao tem pocao")
    }
}
 
func loja(heroi: inout Personagem) {
    let itens = [
        ["nome": "Pocao", "preco": 30],
        ["nome": "Espada de Ferro", "preco": 100],
        ["nome": "Escudo de Carvalho", "preco": 80],
        ["nome": "Cajado do Aprendiz", "preco": 120],
        ["nome": "Arco", "preco": 90]
    ] as [[String: Any]]
    
    print("===== LOJA =====")
    
    for item in itens {
        print("\(item["nome"]!) - \(item["preco"]!) moedas")
    }
    
    if let escolha = readLine() {
        var encontrado = false
        for item in itens {
            
            let nome = item["nome"] as! String
            let preco = item["preco"] as! Int
            if escolha == nome {
                
                encontrado = true
                
                if heroi.moedas >= preco {
                    
                    heroi.moedas -= preco
                    heroi.inventario.append(nome)
                    print("Voce comprou \(nome)!")
                    
                }
                else {
                    print("Moedas insuficientes")
                }
            }
        }
        
        if encontrado == false {
            print("Item nao encontrado")
        }
    }
}
 
func equipar(heroi: inout Personagem) {
    if heroi.inventario.contains("Espada de Ferro") {
        
        heroi.forca += 6
        heroi.inventario.removeAll(where: { $0 == "Espada de Ferro" })
        print("Voce equipou Espada de Ferro!")
    }
    else if heroi.inventario.contains("Escudo de Carvalho") {
        
        heroi.defesa += 5
        heroi.inventario.removeAll(where: { $0 == "Escudo de Carvalho" })
        print("Voce equipou Escudo de Carvalho!")
    }
    else if heroi.inventario.contains("Cajado do Aprendiz") {
        
        heroi.forca += 8
        heroi.inventario.removeAll(where: { $0 == "Cajado do Aprendiz" })
        print("Voce equipou o Cajado!")
    }
    else {
        print("Nao ha itens equipáveis")
    }
}
 
func simularBatalha(heroi: inout Personagem, inimigo: Inimigo) {
    print("===== BATALHA CONTRA \(inimigo.nome) =====")
    print("Escolha o ataque:")
    print("1 - Ataque Fraco")
    print("2 - Ataque Forte")
    print("3 - Ataque Especial")
    
    var danoHeroi = 0
    
    if let escolha = readLine() {
        
        switch escolha {
        case "1":
            danoHeroi = ataqueFraco(forca: heroi.forca)
        case "2":
            danoHeroi = ataqueForte(forca: heroi.forca)
            heroi.defesa -= 2
        case "3":
            danoHeroi = ataqueEspecial(heroi: heroi)
        default:
            danoHeroi = ataqueFraco(forca: heroi.forca)
        }
    }
    
    let danoInimigo = max(1, inimigo.forca - heroi.defesa)
    
    heroi.vidaAtual -= danoInimigo
    
    if heroi.vidaAtual < 0 { heroi.vidaAtual = 0 }
    
    print("Voce causou \(danoHeroi)")
    print("Voce recebeu \(danoInimigo)")
    
    if danoHeroi > danoInimigo {
        
        let r = calcularRecompensas(nivel: inimigo.nivel)
        
        heroi.xp += r.xp
        heroi.moedas += r.moedas
        
        print("Vitoria! XP +\(r.xp) | Moedas +\(r.moedas)")
    }
    else {
        print("Derrota…")
    }
}
 
func historia() {
    print("===== HISTORIA =====")
    print("Eldoria, um reino dividido entre quatro relicias elementais,")
    print("aguarda o retorno do escolhido capaz de reunir os artefatos...")
    print("Seu destino e derrotar o Imperador Caido antes que ele desperte.")
    print("Boa sorte, aventureiro.")
}
 
let inimigos = [
    Inimigo(nome: "Goblin", nivel: 1, forca: 5, defesa: 2, elemento: .none),
    Inimigo(nome: "Lobo Selvagem", nivel: 2, forca: 8, defesa: 3, elemento: .terra),
    Inimigo(nome: "Orc", nivel: 3, forca: 12, defesa: 4, elemento: .terra),
    Inimigo(nome: "Elemental de Fogo", nivel: 4, forca: 15, defesa: 5, elemento: .fogo),
    Inimigo(nome: "Cavaleiro das Sombras", nivel: 5, forca: 18, defesa: 7, elemento: .none)
]

print("Digite o nome do seu heroi:")

let nome = readLine() ?? "Aldren"

print("Escolha sua classe:")
print("1 - Guerreiro")
print("2 - Mago")
print("3 - Ladino")

var classeEscolhida: Classe = .guerreiro

if let c = readLine() {
    
    if c == "2" { classeEscolhida = .mago }
    if c == "3" { classeEscolhida = .ladino }
}

var heroi = criarHeroi(nome: nome, classe: classeEscolhida)
var ativo = true

while ativo {
    print("===== MENU =====")
    print("1 - Status")
    print("2 - Batalhar")
    print("3 - Loja")
    print("4 - Usar Pocao")
    print("5 - Equipar Item")
    print("6 - Historia do Jogo")
    print("7 - Sair")
    
    if let opcao = readLine() {
        switch opcao {
        case "1":
            exibirStatus(heroi)
        case "2":
            simularBatalha(heroi: &heroi, inimigo: inimigos.randomElement()!)
            subirNivel(heroi: &heroi)
        case "3":
            loja(heroi: &heroi)
        case "4":
            usarPocao(heroi: &heroi)
        case "5":
            equipar(heroi: &heroi)
        case "6":
            historia()
        case "7":
            ativo = false
            print("Saindo do jogo...")
            
        default:
            print("Opcao invalida")
        }
    }
}
